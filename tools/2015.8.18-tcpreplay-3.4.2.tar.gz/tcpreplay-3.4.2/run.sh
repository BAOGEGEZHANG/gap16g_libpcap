make uninstall;
make clean;
make 
make install
