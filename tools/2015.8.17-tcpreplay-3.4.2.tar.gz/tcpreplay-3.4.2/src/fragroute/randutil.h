/*
 * randutil.h
 *
 * Copyright (c) 2001 Dug Song <dugsong@monkey.org>
 *
 * $Id: randutil.h 2000 2008-04-27 06:17:35Z aturner $
 */

#ifndef RANDUTIL_H
#define RANDUTIL_H

void		 rand_strset(rand_t *r, void *buf, size_t len);

#endif /* RANDUTIL_H */
