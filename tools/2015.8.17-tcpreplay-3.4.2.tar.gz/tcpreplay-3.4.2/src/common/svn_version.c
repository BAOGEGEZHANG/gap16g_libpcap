const char SVN_Version[] = "2353";
const char *svn_version(void) {
	return SVN_Version;
}
